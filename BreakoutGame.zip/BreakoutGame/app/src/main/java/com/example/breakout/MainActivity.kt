package com.example.breakout

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * ====== GIẢI THÍCH CHO NGƯỜI MỚI ======
 *
 * "class MainActivity : AppCompatActivity()" nghĩa là:
 *   - Ta đang tạo ra một "class" (lớp) tên là MainActivity
 *   - Nó "kế thừa" (dùng dấu ":") từ AppCompatActivity, một lớp có sẵn của Android.
 *     Nhờ vậy MainActivity tự động có đầy đủ khả năng của một "màn hình app".
 *
 * Mỗi app Android luôn cần ít nhất một Activity = một "màn hình".
 * Khi người dùng mở app, Android sẽ tạo ra MainActivity và hiển thị nó lên.
 */
class MainActivity : AppCompatActivity() {

    /**
     * onCreate() là một "hàm" (fun) được Android tự gọi DUY NHẤT 1 LẦN,
     * ngay khi màn hình này được tạo ra lần đầu.
     * Đây là nơi ta thiết lập mọi thứ ban đầu cho màn hình.
     *
     * "override" nghĩa là: ta đang viết lại (ghi đè) một hàm đã có sẵn
     * trong AppCompatActivity, để thêm code riêng của mình vào.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        // Luôn gọi super.onCreate() đầu tiên để Android làm các việc
        // khởi tạo nội bộ của nó trước khi ta thêm code riêng.
        super.onCreate(savedInstanceState)

        // Thay vì thiết kế màn hình bằng file layout XML (cách thường gặp),
        // ở đây ta tự tạo GameView bằng code Kotlin (xem file GameView.kt)
        // và dùng nó làm toàn bộ nội dung hiển thị của màn hình.
        val gameView = GameView(this)

        // setContentView() nói cho Android biết: "hãy hiển thị cái View này
        // lên toàn bộ màn hình".
        setContentView(gameView)
    }
}
